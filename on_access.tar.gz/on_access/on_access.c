#include <linux/module.h>
#include <linux/moduleparam.h>
#include <linux/init.h>
#include <linux/kallsyms.h>
#include <asm/unistd.h>
#include <linux/uaccess.h>
#include <linux/fs.h>
#include <linux/kernel.h>


MODULE_AUTHOR("Oscar Forner Martinez, modified by Weifeng Lin");
MODULE_LICENSE("GPL v2");
MODULE_DESCRIPTION("Revised for CSE 331 Project.");


#define SC_FG 99

//static char *song = NULL;
//static char *pict = NULL;

//module_param(song, charp, 0000);
//MODULE_PARM_DESC(song, "Path to the song to open always.");

//module_param(pict, charp, 0000);
//MODULE_PARM_DESC(pict, "Path to the picture to open always.");

static void **sys_call_table = NULL;

static asmlinkage long (*old_open) (const char __user *filename, int flags);

static asmlinkage long new_open(const char __user *filename, int flags)
{
  if (flags == SC_FG)
    {


      printk(KERN_INFO "NOT Intercepting open(%s, %X, %X)\n", filename, flags);

      return (*old_open)(filename, 0); /*our scan only reads. 0 is readonly flag*/
    }

    /*
      calling user space function. Calling antv.
    */


    char *argv[] = { "/home/weielin/Desktop/cse331/antv/bin/antv","-kscan", "filename", NULL };
    static char *envp[] = {
        "HOME=/",
        "TERM=linux",
        "PATH=/sbin:/bin:/usr/sbin:/usr/bin", NULL };
    call_usermodehelper( argv[0], argv, envp, UMH_WAIT_PROC );



    //sys_call_table[__NR_open] = new_open;


    /* give execution BACK to the original syscall */
    return (*old_open)(filename, flags);
}

static int __init init(void)
{
  
  sys_call_table = (void **)kallsyms_lookup_name("sys_call_table");
  pr_info("Found sys_call_table at %p\n", sys_call_table);
  old_open = sys_call_table[__NR_open];
  sys_call_table[__NR_open] = new_open;
  pr_info("Old open: %p; Rick open: %p\n", old_open, new_open);
  return 0;
}

static void __exit unset(void)
{
  pr_info("Party is over :(\n");
  sys_call_table[__NR_open] = old_open;
}

module_init(init);
module_exit(unset);
